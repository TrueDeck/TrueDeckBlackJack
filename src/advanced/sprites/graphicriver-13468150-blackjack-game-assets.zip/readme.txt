BLACKJACK GAME ASSETS

This Graphic Pack is used in Blackjack
You can try the game here http://codecanyon.net/item/html5-3d-blackjack-html5-casino-game/7909037

What Will You Get?

Assets Foldercontaining:
Croupier Source (.png)
Fiches (.fla)
Message Box(.fla)
Game (.psd)
Sprites Folder (containing)
Background Game 1 (.jpg) Blue Table
Background Game 2 (.jpg) Red Table
Background Game 3 (.jpg) Green Table 
Background Game 4 (.jpg)Purple Table 
Background Menu (.jpg)
Background Menu (.jpg)

Audio Icon(.png)
Arrow Hand (.png)
Bet Background (.png)
Button Exit (.png)
Button Game Background (.png)
Button Game Small Background (.png)
Button Game Very Small (.png)
Button Menu Background (.png)
Card Spritesheet (.png)
Display Background (.png)
Fiche_0 to Fiche_5 (.png)
Money Background (.png)
Message Box (.png)
Progress Bar (.png)
Seat (.png)
Adobe Creator Sofware Used: CS6

The fonts used are
Impact
Open Sans



Please don�t forget to rate our items, We'd really really appreciate it. Thank you very much! 